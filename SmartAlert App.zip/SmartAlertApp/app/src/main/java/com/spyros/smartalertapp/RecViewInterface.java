package com.spyros.smartalertapp;

public interface RecViewInterface {
    void onItemClick(int position);
}
